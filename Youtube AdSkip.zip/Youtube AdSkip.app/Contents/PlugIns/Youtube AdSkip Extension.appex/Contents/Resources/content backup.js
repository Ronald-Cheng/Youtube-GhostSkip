let isEnabled = true;
let observer = null;
let isAdPhase = false;

function ghostSkip() {
    const video = document.querySelector('video');
    const adContainer = document.querySelector('.video-ads.ytp-ad-module, .ad-container, .ad-showing');
    
    // Check if an ad is currently playing
    const adShowing = document.querySelector('.ad-showing') || document.querySelector('.ad-interrupting');

    if (adContainer && video && adShowing) {
        if (!isAdPhase) {
            console.log("👻 Ghost Mode Activated: Hiding Ad...");
            isAdPhase = true;
        }

        // 1. SILENCE & SPEED
        video.muted = true;
        video.playbackRate = 16.0;

        // 2. THE DISAPPEARING ACT
        video.style.position = "absolute";
        video.style.left = "-9999px";
        
        // 3. THE CLICKER (Backup)
        const skipButton = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern');
        if (skipButton) skipButton.click();

        // 4. PREVENT FREEZE
        if (video.paused) video.play();

    } else if (isAdPhase && video) {
        // AD FINISHED: Restore view and playback
        console.log("🎬 Ad sequence finished. Restoring view.");
        isAdPhase = false;
        
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
}

function start() {
    if (observer) return;
    observer = new MutationObserver(ghostSkip);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class']
    });
    ghostSkip(); // Run once to catch ads on page load
}

function stop() {
    if (observer) {
        observer.disconnect();
        observer = null;
    }
    // Force cleanup if extension is turned off
    const video = document.querySelector('video');
    if (video) {
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
    isAdPhase = false;
}

// --- STORAGE & SYNC LOGIC ---

// Initial Load Sync
browser.storage.local.get({ isEnabled: true }).then((res) => {
    isEnabled = res.isEnabled;
    isEnabled ? start() : stop();
});

// Real-time Toggle Listener (Connects to your Popup UI)
browser.storage.onChanged.addListener((changes) => {
    if (changes.isEnabled) {
        isEnabled = changes.isEnabled.newValue;
        isEnabled ? start() : stop();
    }
});
