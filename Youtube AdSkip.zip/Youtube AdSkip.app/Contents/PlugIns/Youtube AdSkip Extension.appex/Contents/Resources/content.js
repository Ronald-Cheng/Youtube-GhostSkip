let isEnabled = true;
let observer = null;
let isAdPhase = false;
let hasGhostSkipped = false;
let skipTimeout = null;

function ghostSkip() {
    const video = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing') || document.querySelector('.ad-interrupting');

    // SCENARIO 1: We are in an active Ad Phase
    if (video && adShowing) {
        if (!isAdPhase) {
            console.log("👻 Ghost Mode Activated: Initiating Sequence...");
            isAdPhase = true;
            hasGhostSkipped = false;
        }

        // 1. IMMEDIATE SILENCE & HIDE (Ambient Experience)
        video.muted = true;
        video.playbackRate = 16.0;
        video.style.position = "absolute";
        video.style.left = "-9999px";

        // 2. THE GHOST SKIP WORKFLOW (0.5s delay -> Jump to End-10s)
        // Ensure this only triggers once per ad, and only if video duration is loaded
        if (!hasGhostSkipped && !skipTimeout && video.duration > 0) {
            skipTimeout = setTimeout(() => {
                // Handle short ads safely: if ad is < 10s, jump to the last 0.5 seconds instead
                const targetTime = video.duration > 10 ? video.duration - 10 : Math.max(0, video.duration - 0.5);
                
                video.currentTime = targetTime;
                console.log(`⏩ Ghost Skipped to ${targetTime}s`);
                
                hasGhostSkipped = true;
                skipTimeout = null; // Clean up timer
            }, 500); // 500ms = 0.5 seconds
        }

        // 3. THE NATIVE CLICKER (Backup)
        // Always check if YouTube provides the official skip button during our 16x sprint
        const skipButton = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern');
        if (skipButton) skipButton.click();

        // 4. PREVENT PLAYER FREEZE
        if (video.paused) video.play();

    // SCENARIO 2: Ad is finished, restore normal video
    } else if (video && !adShowing && isAdPhase) {
        console.log("🎬 Ad sequence finished. Restoring view.");
        
        // Reset states
        isAdPhase = false;
        hasGhostSkipped = false;
        if (skipTimeout) {
            clearTimeout(skipTimeout);
            skipTimeout = null;
        }
        
        // Restore user playback
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
}

function start() {
    if (observer) return;
    observer = new MutationObserver(ghostSkip);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'src'] // Added 'src' to catch video source changes
    });
    ghostSkip(); // Run once to catch ads on page load
}

function stop() {
    if (observer) {
        observer.disconnect();
        observer = null;
    }
    
    if (skipTimeout) {
        clearTimeout(skipTimeout);
        skipTimeout = null;
    }

    // Force cleanup if extension is turned off
    const video = document.querySelector('video');
    if (video) {
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
    isAdPhase = false;
    hasGhostSkipped = false;
}

// --- STORAGE & SYNC LOGIC ---

// Initial Load Sync
if (typeof browser !== 'undefined' && browser.storage) {
    browser.storage.local.get({ isEnabled: true }).then((res) => {
        isEnabled = res.isEnabled;
        isEnabled ? start() : stop();
    });

    // Real-time Toggle Listener
    browser.storage.onChanged.addListener((changes) => {
        if (changes.isEnabled) {
            isEnabled = changes.isEnabled.newValue;
            isEnabled ? start() : stop();
        }
    });
}
