let isEnabled = true;
let observer = null;
let isAdPhase = false;
let hasGhostSkipped = false;
let skipTimeout = null;
let lastAdSrc = ""; // Tracks unique ad video files to reset sequential jumps

function ghostSkip() {
    const video = document.querySelector('video');
    const adShowing = document.querySelector('.ad-showing, .ad-interrupting');

    // SCENARIO 1: We are in an active Ad Phase
    if (video && adShowing) {
        // Detect back-to-back ads (Ad 1 of 2 vs Ad 2 of 2) via source changes
        if (video.src !== lastAdSrc) {
            console.log("🔄 New Ad Asset Detected in Sequence. Resetting Jump Engine.");
            lastAdSrc = video.src;
            hasGhostSkipped = false;
            if (skipTimeout) {
                clearTimeout(skipTimeout);
                skipTimeout = null;
            }
        }

        if (!isAdPhase) {
            console.log("👻 Ghost Mode Activated: Initiating Sequence...");
            isAdPhase = true;
        }

        // 1. IMMEDIATE SILENCE & HIDE
        video.muted = true;
        video.playbackRate = 16.0;
        video.style.position = "absolute";
        video.style.left = "-9999px";

        // 2. THE GHOST SKIP WORKFLOW
        if (!hasGhostSkipped && !skipTimeout && video.duration > 0) {
            skipTimeout = setTimeout(() => {
                // Safeguard against missing elements mid-timeout execution
                if (!document.querySelector('.ad-showing, .ad-interrupting')) return;
                
                const targetTime = video.duration > 10 ? video.duration - 10 : Math.max(0, video.duration - 0.5);
                video.currentTime = targetTime;
                console.log(`⏩ Ghost Skipped to ${targetTime}s`);
                
                hasGhostSkipped = true;
                skipTimeout = null;
            }, 500);
        }

        // 3. THE NATIVE CLICKER (Backup)
        const skipButton = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern');
        if (skipButton) skipButton.click();

        // 4. PREVENT PLAYER FREEZE
        if (video.paused) video.play();

    // SCENARIO 2: Ad sequence completely finished, restore main video view
    } else if (video && !adShowing && isAdPhase) {
        console.log("🎬 Ad sequence completely finished. Restoring view.");
        
        isAdPhase = false;
        hasGhostSkipped = false;
        lastAdSrc = "";
        if (skipTimeout) {
            clearTimeout(skipTimeout);
            skipTimeout = null;
        }
        
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
}

function start() {
    if (observer) return;
    observer = new MutationObserver(ghostSkip);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'src']
    });
    ghostSkip();
}

function stop() {
    if (observer) {
        observer.disconnect();
        observer = null;
    }
    
    if (skipTimeout) {
        clearTimeout(skipTimeout);
        skipTimeout = null;
    }

    const video = document.querySelector('video');
    if (video) {
        video.playbackRate = 1.0;
        video.muted = false;
        video.style.position = "";
        video.style.left = "";
    }
    isAdPhase = false;
    hasGhostSkipped = false;
    lastAdSrc = "";
}

// --- STORAGE & SYNC LOGIC ---
if (typeof browser !== 'undefined' && browser.storage) {
    browser.storage.local.get({ isEnabled: true }).then((res) => {
        isEnabled = res.isEnabled;
        isEnabled ? start() : stop();
    });

    browser.storage.onChanged.addListener((changes) => {
        if (changes.isEnabled) {
            isEnabled = changes.isEnabled.newValue;
            isEnabled ? start() : stop();
        }
    });
}
