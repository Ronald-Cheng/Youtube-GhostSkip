document.addEventListener("DOMContentLoaded", () => {
    const toggle = document.getElementById("toggle");
    const statusText = document.getElementById("status");

    browser.storage.local.get({ isEnabled: true }).then((res) => {
        toggle.checked = res.isEnabled;
        statusText.innerText = res.isEnabled ? "Status: ACTIVE" : "Status: OFF";
    });

    toggle.addEventListener("change", () => {
        const isEnabled = toggle.checked;
        statusText.innerText = isEnabled ? "Status: ACTIVE" : "Status: OFF";
        browser.storage.local.set({ isEnabled });
    });
});
